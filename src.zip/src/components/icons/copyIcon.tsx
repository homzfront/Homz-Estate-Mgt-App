import React from 'react'

const CopyIcon = ({ className = "#006AFF" }) => {
    return (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10.6654 8.5987V11.3987C10.6654 13.732 9.73203 14.6654 7.3987 14.6654H4.5987C2.26536 14.6654 1.33203 13.732 1.33203 11.3987V8.5987C1.33203 6.26536 2.26536 5.33203 4.5987 5.33203H7.3987C9.73203 5.33203 10.6654 6.26536 10.6654 8.5987Z" stroke={className} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M14.6654 4.5987V7.3987C14.6654 9.73203 13.732 10.6654 11.3987 10.6654H10.6654V8.5987C10.6654 6.26536 9.73203 5.33203 7.3987 5.33203H5.33203V4.5987C5.33203 2.26536 6.26536 1.33203 8.5987 1.33203H11.3987C13.732 1.33203 14.6654 2.26536 14.6654 4.5987Z" stroke={className} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    )
}

export default CopyIcon