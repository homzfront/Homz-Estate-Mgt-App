import React from 'react'

const FilterIconBlue = () => {
    return (
        <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3.59896 1.89844H12.399C13.1323 1.89844 13.7323 2.49844 13.7323 3.23177V4.69844C13.7323 5.23177 13.399 5.89844 13.0656 6.23177L10.199 8.7651C9.79896 9.09844 9.53229 9.7651 9.53229 10.2984V13.1651C9.53229 13.5651 9.26563 14.0984 8.93229 14.2984L7.99896 14.8984C7.13229 15.4318 5.93229 14.8318 5.93229 13.7651V10.2318C5.93229 9.7651 5.66563 9.1651 5.39896 8.83177L2.86563 6.1651C2.53229 5.83177 2.26562 5.23177 2.26562 4.83177V3.29844C2.26562 2.49844 2.86563 1.89844 3.59896 1.89844Z" stroke="#006AFF" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    )
}

export default FilterIconBlue