import React from 'react'

const MobileBackButton = () => {
    return (
        <div>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12.5005 16.6004L7.06719 11.1671C6.42552 10.5254 6.42552 9.47539 7.06719 8.83372L12.5005 3.40039" stroke="#006AFF" strokeWidth="1.5" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
        </div>
    )
}

export default MobileBackButton