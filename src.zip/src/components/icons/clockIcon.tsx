import React from 'react'

const ClockIcon = ({ className = "#4E4E4E" }) => {
    return (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M14.6654 7.9987C14.6654 11.6787 11.6787 14.6654 7.9987 14.6654C4.3187 14.6654 1.33203 11.6787 1.33203 7.9987C1.33203 4.3187 4.3187 1.33203 7.9987 1.33203C11.6787 1.33203 14.6654 4.3187 14.6654 7.9987Z" stroke={className} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            <path d="M10.4739 10.1211L8.40724 8.88781C8.04724 8.67448 7.75391 8.16115 7.75391 7.74115V5.00781" stroke={className} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
    )
}

export default ClockIcon