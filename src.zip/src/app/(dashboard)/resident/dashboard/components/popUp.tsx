/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";
import React, { useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';
import ArrowRight from '@/components/icons/arrowRight';
import RevokeIcon from '@/components/icons/revokeIcon';
import useClickOutside from '@/app/utils/useClickOutside';

interface PopUpProps {
    disabledRevoke?: boolean;
    setOpenDetails: (data: boolean) => void;
    fromDefault?: boolean;
    setOpenRevoke: (val: boolean) => void;
    onClose?: () => void;
    anchorRef?: React.RefObject<HTMLButtonElement | null>;
}

function PopUp({ setOpenDetails, fromDefault = true, setOpenRevoke, disabledRevoke = false, onClose, anchorRef }: PopUpProps) {
    const [active, setActive] = React.useState(false);
    const [activeTwo, setActiveTwo] = React.useState(false);
    const [portalStyle, setPortalStyle] = useState<React.CSSProperties | null>(null);
    const portalRef = useRef<HTMLDivElement>(null);

    useClickOutside(anchorRef as any, () => {
        if (onClose) onClose();
    }, anchorRef ? [portalRef as any] : []);

    useEffect(() => {
        const updatePosition = () => {
            if (anchorRef?.current) {
                const rect = anchorRef.current.getBoundingClientRect();
                const isMobile = window.innerWidth < 768;
                const width = isMobile ? 150 : 180;
                const offset = isMobile ? 45 : 75;

                setPortalStyle({
                    position: 'fixed',
                    top: rect.bottom - 20,
                    left: rect.right - width - offset,
                    zIndex: 9999,
                });
            }
        };

        updatePosition();

        // Continuously reposition on scroll so it stays locked to the button
        window.addEventListener('scroll', updatePosition, true);
        window.addEventListener('resize', updatePosition);

        return () => {
            window.removeEventListener('scroll', updatePosition, true);
            window.removeEventListener('resize', updatePosition);
        };
    }, [anchorRef, onClose]);

    const content = (
        <div
            ref={portalRef}
            style={portalStyle || {}}
            className={`drop-down absolute w-[150px] md:w-[180px] text-GrayHomz font-[500] text-[13px] border py-2 rounded-md ${fromDefault ? "bg-[#F6F6F6]" : "bg-white"} md:bg-white flex flex-col items-center justify-around shadow-lg`}
        >
            {/* More Details */}
            <div
                onMouseEnter={() => setActive(true)}
                onMouseLeave={() => setActive(false)}
                className="md:hidden md:h-[30px] h-auto rounded-md flex gap-1 items-center text-GrayHomz hover:text-BlueHomz py-1 px-2 w-full ">
                <div className="w-full ">
                    <div
                        onClick={(e) => {
                            e.stopPropagation()
                            setOpenDetails(true)
                        }}
                        className="cursor-pointer px-2 hover:bg-whiteblue flex gap-1 items-center h-full w-full rounded-md"
                    >
                        <ArrowRight className={active ? '#006AFF' : "#4E4E4E"} />
                        <p className="text-[11px] md:text-[13px] font-[500] py-1 px-2">
                            More Details
                        </p>
                    </div>
                </div>
            </div>
            {/* Revoke Access */}
            <div
                onMouseEnter={() => setActiveTwo(true)}
                onMouseLeave={() => setActiveTwo(false)}
                className={`md:h-[30px] h-auto rounded-md flex gap-1 items-center text-GrayHomz hover:text-BlueHomz py-1 px-2 w-full ${disabledRevoke ? 'opacity-50 pointer-events-none' : ''}`}>
                <div className="w-full ">
                    <div
                        onClick={(e) => {
                            e.stopPropagation()
                            setOpenRevoke(true);
                        }}
                        className="cursor-pointer px-2 hover:bg-whiteblue flex gap-1 items-center h-full w-full rounded-md"
                    >
                        <RevokeIcon className={activeTwo ? '#D92D20' : "#4E4E4E"} />
                        <p className={`${activeTwo ? 'text-[#D92D20]' : "text-[#4E4E4E]"} text-[11px] md:text-[13px] font-[500] py-1 px-2`}>
                            Revoke Access
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )

    // If no anchorRef, render inline (legacy usage)
    if (!anchorRef) {
        return <div style={{ position: 'absolute', top: '36px', right: 0, zIndex: 9999 }}>{content}</div>;
    }

    return (
        <>
            {portalStyle && ReactDOM.createPortal(content, document.body)}
        </>
    );
}

export default PopUp;