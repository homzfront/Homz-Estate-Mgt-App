"use client"
import React from 'react'
import { useAccessStore } from '@/store/useAccessStore'
import EmptyAccess from '@/components/icons/estateManager&Resident/desktop/emptyAccess'
import AddWhiteBox from '@/components/icons/addWhiteBox'
import Dropdown from '@/components/general/dropDown'
import ResetIcon from '@/components/icons/resetIcon'
import AddIcon from '@/components/icons/addIcon'
import CustomModal from '@/components/general/customModal'
import AddManualForm from './components/addManualForm'
import SuccessModal from '../../components/successModal'
import AccessTable from './components/accessTable'
import { useSelectedCommunity } from '@/store/useSelectedCommunity'
import { LoaderIcon } from 'react-hot-toast'
import LoadingSpinner from '@/components/general/loadingSpinner'
import { useAbility } from '@/contexts/AbilityContext'
import { useRouter } from 'next/navigation'
import EmptyEstateState from '../components/emptyEstateState'

const AccessControl = () => {
    const router = useRouter();
    const ability = useAbility();

    // Redirect if user doesn't have access to access control
    React.useEffect(() => {
        if (!ability.can('read', 'access-control')) {
            router.push('/dashboard');
        }
    }, [ability, router]);

    const [steps, setSteps] = React.useState<number>(0);
    const [openSuccessModal, setOpenSuccessModal] = React.useState<boolean>(false);
    const { accessData, setAccessData, fetchManagerAccess, initialLoading, setAccessStatusFilter, accessStatusFilter } = useAccessStore();
    const [openAddManual, setOpenAddManual] = React.useState<boolean>(false);
    const selectedCommunity = useSelectedCommunity((state) => state.selectedCommunity);
    const pages = [
        "All Records", "Manually Added Records"
    ];
    const optionData = [
        { id: 'pending', label: "Pending" },
        { id: 'approved', label: "Approved" },
        { id: 'rejected', label: "Rejected" },
        { id: 'expired', label: "Expired" },
        { id: 'revoke', label: "Revoke" },
        { id: 'used', label: "Used" },
        { id: 'signed in', label: "Signed In" },
        { id: 'signed out', label: "Signed Out" },
    ];


    React.useEffect(() => {
        // On first mount or when community changes, fetch based on current tab
        if (selectedCommunity) {
            fetchManagerAccess({ page: 1, limit: 8, manualOnly: steps === 1 });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [selectedCommunity?.estate?._id])

    const mountedRef = React.useRef(false);
    React.useEffect(() => {
        if (!mountedRef.current) {
            mountedRef.current = true;
            return;
        }
        // Refetch when switching tabs between All Records and Manually Added
        if (selectedCommunity) {
            fetchManagerAccess({ page: 1, limit: 8, manualOnly: steps === 1, accessStatus: accessStatusFilter ?? null });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [steps])



    return (
        <div className='mb-[150px]'>
            {
                openAddManual && ability.can('create', 'access-control') &&
                <CustomModal isOpen={openAddManual} onRequestClose={() => setOpenAddManual(false)}>
                    <AddManualForm
                        setOpenAddManual={setOpenAddManual}
                        setOpenSuccessModal={setOpenSuccessModal}
                    />
                </CustomModal>
            }
            {
                openSuccessModal &&
                <SuccessModal
                    isOpen={openSuccessModal}
                    title='Success! Access Code Sent'
                    color='text-BlueHomz'
                    handleBack={() => {
                        setOpenSuccessModal(false)
                        setSteps(1)
                        fetchManagerAccess({ page: 1, limit: 8, manualOnly: true });
                        setAccessData(true)
                    }}
                    closeSuccessModal={() => {
                        setOpenSuccessModal(false)
                        fetchManagerAccess({ page: 1, limit: 8, manualOnly: steps === 1 });
                    }}
                />
            }
            {!selectedCommunity ?
                <div className='p-8'>
                    <h1 className='text-BlackHomz font-bold text-[16px] md:text-[23px] mb-6'>Visitor Access Control</h1>
                    <EmptyEstateState />
                </div>
                : initialLoading ? (
                    <div className='p-8'>
                        <h1 className='text-BlackHomz font-normal md:font-bold text-[16px] md:text-[23px]'>Visitor Access Control</h1>
                        <div className='h-[60vh] w-full flex items-center justify-center text-GrayHomz'><LoaderIcon /></div>
                    </div>
                ) :
                    <div className='p-8'>
                    <div className='flex justify-between items-center border-b border-[#E6E6E6] pb-8'>
                        <div>
                            <h1 className='text-BlackHomz font-normal md:font-bold text-[16px] md:text-[23px] flex items-center gap-4'>Visitor Access Control {ability.can('create', 'access-control') && <span onClick={() => setOpenAddManual(true)} className='md:hidden bg-whiteblue h-[36px] w-[36px] rounded-[8px] flex items-center justify-center'><AddIcon /></span>}</h1>
                            <h3 className='text-GrayHomz font-normal hidden md:block text-[16px]'>{ability.can('update', 'access-control') ? 'Click on access status to change visitor\'s access status' : 'View visitor access status'}</h3>
                            <h3 className='text-GrayHomz2 font-normal text-sm md:hidden mt-2'>{ability.can('update', 'access-control') ? 'Tap on access status to change visitor\'s access status' : 'View visitor access status'}</h3>
                        </div>
                        {ability.can('create', 'access-control') && (
                            <button onClick={() => setOpenAddManual(true)} className='hidden bg-BlueHomz px-3 h-[37px] rounded-[4px] cursor-pointer text-sm font-normal text-white md:flex items-center gap-1'>
                                <AddWhiteBox /> Register Visitor
                            </button>
                        )}
                    </div>
                    <div className='mt-8'>
                        <div className='flex flex-col-reverse md:flex-row gap-4 md:gap-0 justify-between md:items-center'>
                            <div className='flex items-center gap-2'>
                                {
                                    pages.map((data, index) => (
                                        <div
                                            onClick={() => setSteps(index)}
                                            key={index}
                                            className={`${index === steps ? "text-white bg-BlueHomz" : "bg-whiteblue text-BlueHomz"} text-sm flex items-center px-3 h-[37px] rounded-[4px] cursor-pointer`}
                                        >
                                            {data}
                                        </div>
                                    ))
                                }
                            </div>
                            <div className='flex gap-2 items-center'>
                                <Dropdown
                                    options={optionData}
                                    onSelect={(opt) => {
                                        setAccessStatusFilter(String(opt.id));
                                        fetchManagerAccess({ page: 1, accessStatus: String(opt.id), manualOnly: steps === 1 });
                                    }}
                                    selectOption={"Access Status"}
                                    height='h-[37px]'
                                    borderColor='border-[#A9A9A9]'
                                    showSearch={false}
                                    selectedId={accessStatusFilter}
                                    className='md:min-w-[150px]'
                                />
                                <button
                                    onClick={() => {
                                        setAccessStatusFilter(null);
                                        fetchManagerAccess({ page: 1, accessStatus: null, manualOnly: steps === 1 });
                                    }}
                                    className='px-3 h-[37px] border border-BlueHomz rounded-[4px] flex items-center gap-1 text-BlueHomz text-sm'>
                                    <ResetIcon />Reset
                                </button>
                            </div>
                        </div>
                        <div>
                            {initialLoading ? (
                                <div className='h-[300px] w-full flex items-center justify-center text-GrayHomz'><LoadingSpinner /></div>
                            ) : (
                                <AccessTable
                                    steps={steps}
                                />
                            )}
                        </div>
                    </div>
                </div>
            }
        </div>
    )
}

export default AccessControl